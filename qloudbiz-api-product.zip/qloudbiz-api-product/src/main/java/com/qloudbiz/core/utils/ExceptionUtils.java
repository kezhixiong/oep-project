package com.qloudbiz.core.utils;

/**
 * 统一异常工具类
 * @author Administrator
 *
 */
public class ExceptionUtils {
	
}
